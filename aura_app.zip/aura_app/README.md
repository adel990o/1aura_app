# Aura App

Starter Flutter mobile project with a clean folder structure and SQLite-ready data layer.

## Structure

```text
aura_app/
├── lib/
│   ├── main.dart
│   ├── core/
│   │   ├── theme/
│   │   │   └── app_theme.dart
│   │   └── utils/
│   │       ├── constants.dart
│   │       └── date_helper.dart
│   ├── data/
│   │   ├── models/
│   │   │   ├── activity_log.dart
│   │   │   └── smart_folder.dart
│   │   ├── database/
│   │   │   ├── database_helper.dart
│   │   │   └── migrations/
│   │   │       └── v1_initial.dart
│   │   └── repositories/
│   │       └── activity_repository.dart
│   └── modules/
│       └── dashboard/
│           └── dashboard_screen.dart
├── pubspec.yaml
├── analysis_options.yaml
└── README.md
```

## Getting started

1. Install Flutter SDK.
2. Run `flutter pub get`.
3. Run `flutter run`.

## Included

- Material 3 theme
- Dashboard screen
- Constants and date helpers
- SQLite database helper and initial migration
- Activity repository and sample models
