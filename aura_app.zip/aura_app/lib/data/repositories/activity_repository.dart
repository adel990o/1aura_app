import 'package:sqflite/sqflite.dart';

import '../../core/utils/constants.dart';
import '../database/database_helper.dart';
import '../models/activity_log.dart';

class ActivityRepository {
  const ActivityRepository();

  Future<int> createActivity(ActivityLog activity) async {
    final Database db = await DatabaseHelper.instance.database;
    return db.insert(AppConstants.activityTable, activity.toMap());
  }

  Future<List<ActivityLog>> fetchActivities() async {
    final Database db = await DatabaseHelper.instance.database;
    final List<Map<String, dynamic>> rows = await db.query(
      AppConstants.activityTable,
      orderBy: 'created_at DESC',
    );

    return rows.map(ActivityLog.fromMap).toList();
  }
}
