class SmartFolder {
  final int? id;
  final String name;
  final String rule;
  final DateTime createdAt;

  const SmartFolder({
    this.id,
    required this.name,
    required this.rule,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'rule': rule,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory SmartFolder.fromMap(Map<String, dynamic> map) {
    return SmartFolder(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '',
      rule: map['rule'] as String? ?? '',
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
