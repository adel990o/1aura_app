import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../../core/utils/constants.dart';
import 'migrations/v1_initial.dart';

class DatabaseHelper {
  DatabaseHelper._();

  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, AppConstants.databaseName);

    return openDatabase(
      path,
      version: AppConstants.databaseVersion,
      onCreate: (Database db, int version) async {
        for (final query in V1InitialMigration.queries) {
          await db.execute(query);
        }
      },
    );
  }
}
