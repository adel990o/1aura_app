class V1InitialMigration {
  V1InitialMigration._();

  static const List<String> queries = <String>[
    '''
    CREATE TABLE activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
    ''',
    '''
    CREATE TABLE smart_folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      rule TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
    ''',
  ];
}
