class AppConstants {
  AppConstants._();

  static const String appName = 'Aura App';
  static const String databaseName = 'aura_app.db';
  static const int databaseVersion = 1;

  static const String activityTable = 'activity_logs';
  static const String smartFolderTable = 'smart_folders';
}
